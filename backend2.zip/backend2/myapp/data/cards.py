cards = [
    { "id": 1, "name": "Ace of Spades", "image": "/cardImages/ffive.png" },
    { "id": 2, "name": "King of Hearts", "image":  "/cardImages/sthree.png" },
    { "id": 3, "name": "Queen of Diamond", "image": "/cardImages/hsix.png" },    
    { "id": 5, "name": "Queen of Diamond", "image": "/cardImages/hsix.png" },   
    { "id": 6, "name": "King of Hearts", "image":  "/cardImages/sthree.png" },
    { "id": 7, "name": "Queen of Diamond", "image": "/cardImages/hsix.png" },
]
